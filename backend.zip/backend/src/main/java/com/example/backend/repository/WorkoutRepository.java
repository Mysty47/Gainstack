package com.example.backend.repository;

import com.example.backend.entity.Workout;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkoutRepository extends JpaRepository<Workout, Long> {
    List<Workout> findAllByOrderByWorkoutDateDesc();
}
